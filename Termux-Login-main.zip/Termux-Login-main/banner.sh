banner () {
clear

echo""
echo""
echo""
echo""
echo""
echo""
echo""
echo""
echo"" 
echo""
echo""
echo""
echo""
echo -e '\e[1;32m 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
\e[0m'
echo""
echo""
echo""
echo""
echo -e"
\e[1;32m         /█1%...................../ \e[0m"
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo -e '\e[1;32m 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "       "/█4%....................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '

                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "        "/█8%......................./
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "         "/██10%....................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e ' 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "         "/██12%....................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "         "/███15%..................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e ' 
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "        "/█████19%..................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "        "/██████28%..................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "       "/████████30%................../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "        "/██████████40%................/
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "         "/█████████████50%............./
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "        "/████████████████60%........../
sleep 0.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e '
                     ┬  ┌─┐┌─┐┌┬┐┬┌┐┌┌─┐
                     │  │ │├─┤ │││││││ ┬
                     ┴─┘└─┘┴ ┴─┴┘┴┘└┘└─┘
'
echo " "
echo " "
echo " "
echo " "
echo  -e "       "/███████████████████88%......./
sleep 0.0

clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
echo  -e "       "/██████████████████████████████100%....../
sleep 0.2
clear


echo -e "\033[32m\033[1m
       
               ╔═╗┬┌─┐┌┐┌  ╦ ╦┌─┐  
              \033[33m ╚═╗││ ┬│││  ║ ║├─┘ \033[32m 
               ╚═╝┴└─┘┘└┘  ╚═╝┴    
  \033[33m________________________________________________
  \033[31mWarning:\033[37mDon't Forget Your \033[35mUsernames \033[37mand \033[35mPassword
  \033[33m________________________________________________

     \033[1m\033[36mTool Name       \033[32m: \033[33mTermux-Login
     \033[1m\033[36mAuthor_Name     \033[32m: \033[33m gkvai
     \033[1m\033[36mYouTube_Channel \033[32m: \033[33mtupadre 
     \033[1m\033[36mCountry         \033[32m: \033[33mdhaka
     \033[1m\033[36mState           \033[32m: \033[33mgazipur  
  \033[31m________________________________________________
"


}
banner 
